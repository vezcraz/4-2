from randomizer import placeRandom
from scores import getSum,maxTile
def initializeGrid(grid):
	board=[]
	for i in range(4):
		temp = []
		for j in range(4):
			temp.append(0)
		board.append(temp)
	placeRandom(board)
	placeRandom(board)
	score= getSum(board) #score at beginning
	mx = maxTile(board) #max tile value at beginning
	grid['board']=board
	grid['score']=score
	grid['max'] = mx


