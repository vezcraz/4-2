from rotate import *
import copy
from randomizer import placeRandom
from init import initializeGrid #function to initialize board and scores
from show import display #funntion to display board and scores

gr={} #a dictionary to store a single state and its scores
initializeGrid(gr) #initializes the grid with two random values
print("Initial State:")
grid = gr['board']
display(grid)


def makeMove( op):
	changes=0
	done = set()
	temp = copy.deepcopy(grid)
	for r in range(1,4):
		row=r
		while(row!=0):
			for i in range(4):
				if ((row-1,i) in done) or ((row,i) in done):
					continue
				elif grid[row-1][i]==0:
					grid[row-1][i]=grid[row][i]
					grid[row][i]=0
				elif grid[row][i]==grid[row-1][i] or op=="ADD":
					if grid[row-1][i]!=0:
						done.add((row-1,i))

					if op=="SUBTRACT":
						grid[row-1][i]  = 0

					elif op=="MULTIPLY":
						grid[row-1][i]  = grid[row-1][i]*grid[row][i]
						
					elif op=="DIVIDE":
						grid[row-1][i]  = 1
					else:
						grid[row-1][i]  = grid[row-1][i]+grid[row][i]
						
					grid[row][i]=0
			row-=1

	if(temp==grid):
		return 0
	placeRandom(grid)
	return 1

rotBy = {"UP":0, "LEFT":1, "DOWN":2,"RIGHT":3}
def updateGrid(x, op):
	rotate90x(rotBy[x], grid)
	changed=makeMove( op)
	rotate90x(4-rotBy[x], grid)
	if(changed):
		display(grid)

def valid(x,y): #check if the cell is inside the grid
	return x>=1 and x<=4 and y>=1 and y<=4

def assignCell(val,x,y):
	if(val>=0 and valid(x,y)):
		grid[x-1][y-1]=val
		display(grid)

