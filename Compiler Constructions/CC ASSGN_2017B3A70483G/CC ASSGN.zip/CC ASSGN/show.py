def display(grid):
	board  = grid
	for row in board:
		for el in row:
			if el==0:
				print('_', end = '     ')
			else:
				print(el, end='     ')
		print()
		print()
	# print(f'Score:{score}, Max Tile:{mx}')
	# print("---------------------")


