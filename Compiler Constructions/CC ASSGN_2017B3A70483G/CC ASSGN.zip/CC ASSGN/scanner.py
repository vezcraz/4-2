import ply.lex as lex
import ply.yacc as yacc
import sys
# from update import updateGrid,
tokens = [
	'operation',
	'move',
	'assignment',
	'to',
	'integer',
	'stop',
	'comma',

]

t_to = r'TO'
t_operation = r'ADD|SUBTRACT|MULTIPLY|DIVIDE'
t_move = r'UP|RIGHT|LEFT|DOWN'
t_assignment = r'ASSIGN'
t_ignore = r' '
t_stop = r'\.'
t_comma = r'\,'

def t_integer(t):
	r'\d+'
	t.value = 	int(t.value)
	return t

def t_error(t):
	print(t)
	print("Syntax error")
	t.lexer.skip(100)

lexer = lex.lex()