import ply.lex as lex
import ply.yacc as yacc
from scanner import *
import sys
from update import updateGrid, assignCell
def p_evaluate(p):
	'''
	evaluate : exp_assign
			 | exp_move
			 | no_stop
			 | empty
	'''

def p_exp_assign(p):
	'''
	exp_assign : assignment integer to integer comma integer stop
	'''
	p[0]= (p[2], p[4], p[6])
	print(p[0])
	run_assign(p[0])

def p_exp_move(p):
	'''
	exp_move : operation move stop
	'''
	p[0]= (p[1],p[2])
	print(p[0])
	run_move(p[0])

def p_fullStop(p):
	'''
	no_stop : operation move
            | assignment integer to integer comma integer
	'''
	print("Full Stop Not Provided")

def p_empty(p):
	'''
	empty :
	'''

def run_assign(p):
	val,x,y = p
	assignCell(val , x, y)

def run_move(p):
	op,direction = p
	updateGrid(direction,op)

def p_error(p):
	pass

parserObj = yacc.yacc()

