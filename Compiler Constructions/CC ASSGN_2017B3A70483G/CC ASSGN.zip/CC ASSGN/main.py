import os
import copy
import random 
from scores import getSum,maxTile #functions to get the values of score,mx
from randomizer import placeRandom,getRandomInput #functions to randomize inputs
from update import updateGrid, assignCell #functions to make moves and update
from show import display #funntion to display board and scores
from parser import parserObj


while True:
	try:
		inp = input('')
	except EOFError:
		break
	parserObj.parse(inp)

# while True:
# 		x = input().split()[0]
# 		print(x)
# 		prev=copy.deepcopy(grid) 
# 		changed=updateGrid(str(x),grid['board']) #makes the move and updates the board pos
# 		#update score,mx
# 		grid['max'] = maxTile(grid['board']) 
# 		grid['score']=getSum(grid['board'])
# 		if changed: #display the board if the move makes any changes
# 			print(f'Input Given: {x}')
# 			display(grid)