from main import grid
from update import updateGrid, assignCell
def assigner(val,x, y):
	changed=assignCell(grid, val, x, y)
	if changed:
		display(grid)

def updater(direction, op):
	changed = updateGrid(direction, grid, op)
	if changed:
		display(grid)