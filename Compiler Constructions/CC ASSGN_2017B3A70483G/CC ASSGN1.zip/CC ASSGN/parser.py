import ply.lex as lex
import ply.yacc as yacc
from scanner import *
import sys
from update import updateGrid, assignCell, nameCell
from stderrPrinter import eprint
def p_evaluate(p):
	'''
	evaluate : exp_assign
			 | exp_move
			 | exp_naming
			 | no_stop
			 | empty
	'''

def p_exp_assign(p):
	'''
	exp_assign : assignment integer to integer comma integer stop
	'''
	p[0]= (p[2], p[4], p[6])
	print(p[0])
	run_assign(p[0])

def p_exp_move(p):
	'''
	exp_move : operation move stop
	'''
	p[0]= (p[1],p[2])
	print(p[0])
	run_move(p[0])

def p_exp_naming(p):
	'''
	exp_naming : integer comma integer is string stop
			   | integer comma integer is operation stop	
			   | integer comma integer is move stop	
			   | integer comma integer is assignment stop
			   | integer comma integer is is stop

	'''
	run_name((p[1],p[3],p[5]))


def p_fullStop(p):
	'''
	no_stop : operation move
            | assignment integer to integer comma integer
            | integer comma integer is string
	'''
	print("Full Stop Not Provided")
	eprint(-1)

def p_empty(p):
	'''
	empty :
	'''

def run_assign(p):
	val,x,y = p
	assignCell(val , x, y)

def run_move(p):
	op,direction = p
	updateGrid(direction,op)

def run_name(p):
	x,y,name = p
	nameCell(x,y,name)

def p_error(p):
	# print(p)
	print("Syntax Error")

parserObj = yacc.yacc()

