import os
import copy
import random 
from scores import getSum,maxTile #functions to get the values of score,mx
from randomizer import placeRandom,getRandomInput #functions to randomize inputs
from update import updateGrid, assignCell #functions to make moves and update
from show import display #funntion to display board and scores
from parser import parserObj


while True:
	try:
		inp = input('')
	except EOFError:
		break
	parserObj.parse(inp)
