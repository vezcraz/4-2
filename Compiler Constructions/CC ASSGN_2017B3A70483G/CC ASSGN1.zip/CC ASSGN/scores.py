def maxTile(grid):
	return max(list(map(max,grid)))
def getSum(grid):
	return sum(list(map(sum,grid)))