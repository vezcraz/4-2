from rotate import *
import copy
from randomizer import placeRandom
from init import initializer #function to initialize board and scores
from show import * #funntion to display board and scores

grid=[] #a dictionary to store a single state and its scores
idx=[]
initializer(grid, idx) #initializes the grid with two random values
print("Initial State:")
display(grid)
nameSet = set()
cellToName = {}
def makeMove( op):
	changes=0
	done = set()
	temp = copy.deepcopy(grid)
	for r in range(1,4):
		row=r
		while(row!=0):
			for i in range(4):
				x = idx[row][i]
				nx = idx[row-1][i]
				xSet = copy.deepcopy(cellToName[x])

				if ((row-1,i) in done) or ((row,i) in done) or grid[row][i][0]==0:
					continue
				elif grid[row-1][i]==0:
					grid[row-1][i]=grid[row][i]
					grid[row][i]=0
					cellToName[nx] = copy.deepcopy(xSet)
					cellToName[x] = set()

				elif grid[row][i]==grid[row-1][i] or op=="ADD":
					done.add((row-1,i))
					if op=="SUBTRACT":
						grid[row-1][i]  = 0
						for nam in cellToName[nx]:
							nameSet.remove(nam)
						for nam in cellToName[x]:
							nameSet.remove(nam)
						cellToName[nx]= set()
					elif op=="MULTIPLY":
						grid[row-1][i]  = grid[row-1][i]*grid[row][i]
						cellToName[nx]|=xSet
					elif op=="DIVIDE":
						grid[row-1][i]  = 1
						cellToName[nx]|=xSet
					else:
						grid[row-1][i]  = grid[row-1][i]+grid[row][i]
						cellToName[nx]|=xSet
					cellToName[x]=set()
					grid[row][i]=0
			row-=1

	if(temp==grid):
		return 0
	placeRandom(grid)
	displayErr(grid, nameToCell)
	return 1

rotBy = {"UP":0, "LEFT":1, "DOWN":2,"RIGHT":3}
def updateGrid(x, op):
	rotate90x(rotBy[x], grid)
	rotate90x(rotBy[x], idx)
	changed=makeMove( op)
	rotate90x(4-rotBy[x], grid)
	rotate90x(4-rotBy[x], idx)
	if(changed):
		display(grid)

def valid(x,y): #check if the cell is inside the grid
	return x>=1 and x<=4 and y>=1 and y<=4

def assignCell(val,x,y):
	if(val>=0 and valid(x,y)):
		grid[x-1][y-1]=val
		display(grid)

keywords = [
	'ADD',
	'SUBTRACT',
	'MULTIPLY',
	'DIVIDE',
	'LEFT',
	'RIGHT',
	'UP',
	'DOWN',
	'ASSIGN',
	'TO',
	'VAR',
	'IS',
	'VALUE',
	'IN',

]

def nameCell(x,y,st):
	if st in keywords:
		print("No, a keyword cannot be a variable name")
	elif st in nameSet:
		print("This name has already been used")
	else:
		nameSet.add(st)
		if len(cellToName[(x,y)])==0:
			cellToName[(x,y)]=set()
		cellToName[(x,y)].add(st)
